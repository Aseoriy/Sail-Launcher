// Hardware Monitor Plugin for Sail Launcher
// Compact real-time CPU, RAM, GPU usage indicator

module.exports = function(SailAPI) {
    const os = require('os');
    const { execFile } = require('child_process');
    const fs = require('fs');

    const widget = document.createElement('div');
    widget.id = 'hw-monitor-widget';
    widget.innerHTML = `
        <style>
            #hw-monitor-widget {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                padding: 4px 10px;
                background: rgba(0, 0, 0, 0.35);
                backdrop-filter: blur(10px);
                border: 1px solid var(--border-color, rgba(255,255,255,0.08));
                border-radius: 8px;
                font-size: 10px;
                font-family: 'Segoe UI', sans-serif;
                color: var(--text-color, #ccc);
                user-select: none;
                flex-shrink: 0;
                -webkit-app-region: no-drag;
                height: 26px;
                margin-left: 12px;
            }
            #hw-monitor-widget:hover { border-color: var(--accent, rgba(168,85,247,0.4)); }
            .hw-m { display: flex; align-items: center; gap: 3px; font-variant-numeric: tabular-nums; }
            .hw-m .hw-l { opacity: 0.5; font-weight: 600; font-size: 9px; }
            .hw-m .hw-v { font-weight: 700; min-width: 26px; text-align: right; }
            .hw-d { width: 1px; height: 12px; background: rgba(255,255,255,0.1); }
        </style>
        <div class="hw-m"><span class="hw-l">CPU</span><span class="hw-v" id="hwCpu">--%</span></div>
        <div class="hw-d"></div>
        <div class="hw-m"><span class="hw-l">RAM</span><span class="hw-v" id="hwRam">--%</span></div>
        <div class="hw-d"></div>
        <div class="hw-m"><span class="hw-l">GPU</span><span class="hw-v" id="hwGpu">--%</span></div>
    `;

    // Always insert into the titlebar — it never moves
    const titleDiv = document.querySelector('.titlebar-title');
    if (titleDiv) {
        // Insert after the "Sail Launcher" span and before the topHeader containers
        const topContainer = document.getElementById('topHeaderActionButtonsContainer');
        if (topContainer) {
            titleDiv.insertBefore(widget, topContainer);
        } else {
            titleDiv.appendChild(widget);
        }
    }

    function colorize(el, pct) {
        if (pct < 50) el.style.color = '#10b981';
        else if (pct < 80) el.style.color = '#f59e0b';
        else el.style.color = '#ef4444';
    }

    let prevCpu = null;
    function getCpu() {
        const cpus = os.cpus();
        let idle = 0, total = 0;
        cpus.forEach(c => { for (let t in c.times) total += c.times[t]; idle += c.times.idle; });
        if (prevCpu) {
            const di = idle - prevCpu.idle, dt = total - prevCpu.total;
            prevCpu = { idle, total };
            return dt > 0 ? ((1 - di / dt) * 100) : 0;
        }
        prevCpu = { idle, total };
        return 0;
    }

    function getRam() {
        // Linux keeps file cache in "free" memory, so use MemAvailable like system monitors do.
        if (process.platform === 'linux') {
            try {
                const info = fs.readFileSync('/proc/meminfo', 'utf8');
                const total = Number(/MemTotal:\s+(\d+)/.exec(info)[1]), available = Number(/MemAvailable:\s+(\d+)/.exec(info)[1]);
                if (total > 0) return (1 - available / total) * 100;
            } catch (_) { /* Fall back to the generic reading. */ }
        }
        return ((os.totalmem() - os.freemem()) / os.totalmem()) * 100;
    }

    // AMD and some Intel GPUs report load through sysfs on Linux when nvidia-smi is not available.
    function sysfsGpuLoad() {
        try {
            for (const card of fs.readdirSync('/sys/class/drm')) {
                if (!/^card\d+$/.test(card)) continue;
                const value = Number.parseFloat(fs.readFileSync(`/sys/class/drm/${card}/device/gpu_busy_percent`, 'utf8'));
                if (Number.isFinite(value)) return value;
            }
        } catch (_) { /* No readable GPU load. */ }
        return -1;
    }

    let gpuQueryInFlight = false;
    function updateGpu(gpuEl) {
        if (!gpuEl || gpuQueryInFlight) return;
        gpuQueryInFlight = true;
        execFile(process.platform === 'win32' ? 'nvidia-smi.exe' : 'nvidia-smi', ['--query-gpu=utilization.gpu', '--format=csv,noheader,nounits'], {
            timeout: 2000,
            windowsHide: true,
            maxBuffer: 64 * 1024
        }, (error, stdout) => {
            gpuQueryInFlight = false;
            if (!gpuEl.isConnected) return;
            let gpu = error ? -1 : Number.parseFloat(String(stdout).trim());
            if (!(gpu >= 0) && process.platform === 'linux') gpu = sysfsGpuLoad();
            if (Number.isFinite(gpu) && gpu >= 0) {
                gpuEl.textContent = Math.round(gpu) + '%';
                colorize(gpuEl, gpu);
            } else {
                gpuEl.textContent = 'N/A';
            }
        });
    }

    function update() {
        if (document.hidden) return;
        const cpuEl = document.getElementById('hwCpu');
        const ramEl = document.getElementById('hwRam');
        const gpuEl = document.getElementById('hwGpu');

        const cpu = getCpu();
        if (cpuEl) { cpuEl.textContent = Math.round(cpu) + '%'; colorize(cpuEl, cpu); }

        const ram = getRam();
        if (ramEl) { ramEl.textContent = Math.round(ram) + '%'; colorize(ramEl, ram); }

        updateGpu(gpuEl);
    }

    update();
    setInterval(update, 5000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) update(); });
    console.log('[Plugin] Hardware Monitor loaded');
};
